Action()
{

	web_url("kalimanjaro.hpswlabs.adapps.hp.com", 
		"URL=http://kalimanjaro.hpswlabs.adapps.hp.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://www.bing.com/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_link("https sites.", 
		"Text=https sites.", 
		"Snapshot=t2.inf", 
		LAST);

	web_link("All kind of CGI's.", 
		"Text=All kind of CGI's.", 
		"Snapshot=t3.inf", 
		LAST);

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=ieonline.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20160321; DOMAIN=ieonline.microsoft.com");

	web_add_cookie("SRCHUID=V=2&GUID=3B7754DC2316455F8C27CF200DB55E6B; DOMAIN=ieonline.microsoft.com");

	web_url("fwlink", 
		"URL=https://go.microsoft.com/fwlink/?LinkId=251136", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_url("example-5.html", 
		"URL=https://kalimanjaro/cgi_examples/example-5.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://kalimanjaro/cgi_examples/cgi_overview.html", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(5);

	web_link("Back to example 4", 
		"Text=Back to example 4", 
		"Snapshot=t6.inf", 
		LAST);

	web_link("Back to example 3", 
		"Text=Back to example 3", 
		"Snapshot=t7.inf", 
		LAST);

	web_link("Back to example 2", 
		"Text=Back to example 2", 
		"Snapshot=t8.inf", 
		LAST);

	web_link("Back to example 1", 
		"Text=Back to example 1", 
		"Snapshot=t9.inf", 
		LAST);

	lr_think_time(4);

	web_link("Go back to CGI examples homepage", 
		"Text=Go back to CGI examples homepage", 
		"Snapshot=t10.inf", 
		LAST);

	web_link("Example 1", 
		"Text=Example 1", 
		"Snapshot=t11.inf", 
		LAST);

	web_link("Go back to CGI examples homepage_2", 
		"Text=Go back to CGI examples homepage", 
		"Snapshot=t12.inf", 
		LAST);

	lr_think_time(7);

	web_url("kalimanjaro", 
		"URL=https://kalimanjaro/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_link("All kind of Links.", 
		"Text=All kind of Links.", 
		"Snapshot=t14.inf", 
		LAST);

	web_link("Go to index page", 
		"Text=Go to index page", 
		"Snapshot=t15.inf", 
		LAST);

	web_link("New Mercury Tours", 
		"Text=New Mercury Tours", 
		"Snapshot=t16.inf", 
		LAST);

	lr_save_string(lr_decrypt("56efb40be4d9740a"), "PasswordParameter");

	lr_think_time(9);

	web_submit_data("login.pl", 
		"Action=https://kalimanjaro/WebTours/login.pl", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://kalimanjaro/WebTours/nav.pl?in=home", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value=118149.020575132zAHHcQApctfiDDDDDztzDpHtVtHf", ENDITEM, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value={PasswordParameter}", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=login.x", "Value=0", ENDITEM, 
		"Name=login.y", "Value=0", ENDITEM, 
		LAST);

	lr_think_time(4);

	web_image("Search Flights Button", 
		"Alt=Search Flights Button", 
		"Snapshot=t18.inf", 
		EXTRARES, 
		"Url=FormDateUpdate.class", "Referer=", ENDITEM, 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_url("WebTours", 
		"URL=https://kalimanjaro/WebTours/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	lr_think_time(14);

	web_submit_data("reservations.pl", 
		"Action=https://kalimanjaro/WebTours/reservations.pl", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://kalimanjaro/WebTours/reservations.pl?page=welcome", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value=Portland", ENDITEM, 
		"Name=departDate", "Value=03/22/2016", ENDITEM, 
		"Name=arrive", "Value=Paris", ENDITEM, 
		"Name=returnDate", "Value=03/23/2016", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=seatPref", "Value=Window", ENDITEM, 
		"Name=seatType", "Value=First", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		"Name=findFlights.x", "Value=37", ENDITEM, 
		"Name=findFlights.y", "Value=9", ENDITEM, 
		LAST);

	lr_think_time(6);

	web_submit_form("reservations.pl_2", 
		"Snapshot=t21.inf", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=542;1101;03/22/2016", ENDITEM, 
		"Name=reserveFlights.x", "Value=48", ENDITEM, 
		"Name=reserveFlights.y", "Value=11", ENDITEM, 
		LAST);

	lr_think_time(11);

	web_submit_form("reservations.pl_3", 
		"Snapshot=t22.inf", 
		ITEMDATA, 
		"Name=firstName", "Value=Jojo", ENDITEM, 
		"Name=lastName", "Value=Bean", ENDITEM, 
		"Name=address1", "Value=", ENDITEM, 
		"Name=address2", "Value=", ENDITEM, 
		"Name=pass1", "Value=Jojo Bean", ENDITEM, 
		"Name=creditCard", "Value=3695478", ENDITEM, 
		"Name=expDate", "Value=12/16", ENDITEM, 
		"Name=saveCC", "Value=<OFF>", ENDITEM, 
		"Name=buyFlights.x", "Value=72", ENDITEM, 
		"Name=buyFlights.y", "Value=17", ENDITEM, 
		LAST);

	web_url("welcome.pl", 
		"URL=https://kalimanjaro/WebTours/welcome.pl?page=menus", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://kalimanjaro/WebTours/nav.pl?page=menu&in=flights", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(4);

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Snapshot=t24.inf", 
		LAST);

	lr_think_time(4);

	web_url("kalimanjaro_2", 
		"URL=https://kalimanjaro/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_link("WinRunner", 
		"Text=WinRunner", 
		"Snapshot=t26.inf", 
		LAST);

	lr_think_time(4);

	web_link("Titanic movie.", 
		"Text=Titanic movie.", 
		"Snapshot=t27.inf", 
		LAST);

	return 0;
}